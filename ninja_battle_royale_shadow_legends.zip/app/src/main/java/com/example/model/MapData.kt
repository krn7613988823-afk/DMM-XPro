package com.example.model

data class MapLocation(
    val id: String,
    val name: String,
    val bengaliName: String,
    val description: String,
    val center: Vector3,
    val radius: Float,
    val primaryLootTier: String,
    val landmarkStyle: String
)

data class Building3D(
    val id: String,
    val name: String,
    val position: Vector3,
    val width: Float,
    val height: Float,
    val depth: Float,
    val colorHex: Long,
    val hasRooftopAccess: Boolean = true
)

data class LootCrate(
    val id: String,
    val position: Vector3,
    val weapon: WeaponData,
    val ammoCount: Int,
    var isLooted: Boolean = false
)

data class JumpPad(
    val id: String,
    val position: Vector3,
    val launchForceY: Float = 18f,
    val launchForward: Float = 12f
)

data class SafeZone(
    var center: Vector3 = Vector3(0f, 0f, 0f),
    var currentRadius: Float = 300f,
    var targetRadius: Float = 300f,
    var shrinkRatePerSec: Float = 1.2f,
    var phase: Int = 1,
    var timerSeconds: Float = 120f,
    var damagePerSecond: Float = 5f
)

object NeoDhakaMap {
    val LOCATIONS = listOf(
        MapLocation("sangsad", "Sangsad Bhaban District", "সংসদ ভবন এলাকা", "Central endgame zone with grand marble corridors and lakes.", Vector3(0f, 0f, 0f), 120f, "LEGENDARY", "marble_columns"),
        MapLocation("du", "Dhaka University Quarter", "ঢাকা বিশ্ববিদ্যালয়", "Curzon red brick architecture, library rooftops, and academic pavilions.", Vector3(-150f, 0f, 80f), 90f, "HIGH", "curzon_brick"),
        MapLocation("gulistan", "Gulistan Market", "গুলিস্তান মার্কেট", "Dense bazaar, vibrant stalls, high loot density and close melee combat.", Vector3(80f, 0f, -120f), 85f, "MEDIUM", "market_stalls"),
        MapLocation("mirpur", "Mirpur Dojo Grounds", "মিরপুর দোযো", "Ancient martial arts ninja academy, weapon racks and training dummies.", Vector3(-200f, 0f, -150f), 95f, "HIGH_MELEE", "dojo_temple"),
        MapLocation("uttara", "Uttara High-Rises", "উত্তরা হাইরাইজ", "Modern steel skyscrapers, vertical zip traversal and rooftop jump pads.", Vector3(180f, 0f, 160f), 110f, "SNIPER", "skyscraper"),
        MapLocation("old_dhaka", "Old Dhaka Alleys", "পুরান ঢাকা", "Narrow winding passages, historic heritage, street food stalls.", Vector3(120f, 0f, -220f), 80f, "CLOSE_COMBAT", "heritage_brick"),
        MapLocation("padma", "Padma Bridge Crossing", "পদ্মা সেতু ভিউ", "Massive suspension bridge, elevated sightlines for AWM snipers.", Vector3(-180f, 15f, 220f), 130f, "SNIPER_GOLD", "steel_truss"),
        MapLocation("sundarban", "Sundarban Forest Edge", "সুন্দরবন জঙ্গল", "Mangrove thickets, swamp mist, stealth cover and wild tiger tracks.", Vector3(-260f, 0f, -40f), 100f, "STEALTH", "mangrove_roots"),
        MapLocation("cox_bazar", "Cox's Bazar Shoreline", "কক্সবাজার সৈকত", "Golden sands, coastal breeze, lighthouse towers and docks.", Vector3(250f, 0f, -80f), 115f, "HIGH", "lighthouse_beach"),
        MapLocation("noyakhali", "Noyakhali Hidden Temple", "নোয়াখালী মন্দির", "Secret sanctuary holding Gold Katana Ultimate.", Vector3(50f, 0f, 260f), 70f, "MYTHIC", "secret_shrine")
    )

    // Modular 3D Buildings for the Playable Arena
    val TEST_ARENA_BUILDINGS = listOf(
        Building3D("bldg_center_sangsad", "Central Pavilion", Vector3(0f, 0f, 0f), 24f, 8f, 24f, 0xFF1B2A47),
        Building3D("bldg_dojo_west", "Mirpur Training Hall", Vector3(-45f, 0f, -25f), 18f, 6f, 18f, 0xFF2A1B1B),
        Building3D("bldg_tower_north", "Uttara Highrise Tower", Vector3(20f, 0f, 50f), 16f, 14f, 16f, 0xFF14243B),
        Building3D("bldg_market_east", "Gulistan Street Shops", Vector3(50f, 0f, -20f), 22f, 5f, 14f, 0xFF352A18),
        Building3D("bldg_curzon_south", "Curzon Hall Brick Pavilion", Vector3(-35f, 0f, 40f), 20f, 7f, 18f, 0xFF3A1818)
    )

    val ARENA_JUMP_PADS = listOf(
        JumpPad("pad_1", Vector3(10f, 0f, 18f), 16f, 8f),
        JumpPad("pad_2", Vector3(-25f, 0f, -10f), 16f, 8f),
        JumpPad("pad_3", Vector3(32f, 0f, -15f), 18f, 10f)
    )

    val ARENA_LOOT_CRATES = listOf(
        LootCrate("crate_1", Vector3(0f, 8f, 0f), WeaponRegistry.GOLD_KATANA_ULTIMATE, 30),
        LootCrate("crate_2", Vector3(-45f, 6f, -25f), WeaponRegistry.SHADOW_KATANA, 20),
        LootCrate("crate_3", Vector3(20f, 14f, 50f), WeaponRegistry.AWM_GOLD, 10),
        LootCrate("crate_4", Vector3(50f, 5f, -20f), WeaponRegistry.AK_BD, 90),
        LootCrate("crate_5", Vector3(-35f, 7f, 40f), WeaponRegistry.SHURIKEN, 25),
        LootCrate("crate_6", Vector3(15f, 0f, -30f), WeaponRegistry.TIGER_CLAW, 15)
    )
}
