package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.*
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.*

@Composable
fun GameScreen(
    engine: GameEngine,
    onReturnToLobby: () -> Unit,
    onOpenGkJutsu: () -> Unit,
    onOpenSettings: () -> Unit
) {
    // 60 FPS Render Tick Loop
    var lastFrameNanos by remember { mutableLongStateOf(System.nanoTime()) }
    var moveJoystickX by remember { mutableFloatStateOf(0f) }
    var moveJoystickY by remember { mutableFloatStateOf(0f) }
    var renderTick by remember { mutableIntStateOf(0) }

    val renderer = remember { Renderer3D() }

    // Coroutine loop for 60 FPS engine updates
    LaunchedEffect(Unit) {
        while (true) {
            withFrameNanos { now ->
                val dt = ((now - lastFrameNanos) / 1_000_000_000f).coerceIn(0.005f, 0.05f)
                lastFrameNanos = now

                engine.update(dt, moveJoystickX, moveJoystickY)
                renderTick++
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ShadowBlack)
    ) {
        // 1. 3D Game Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("game_viewport_canvas")
        ) {
            // Read renderTick to trigger recomposition on every tick
            val tick = renderTick
            renderer.renderScene(
                scope = this,
                camera = engine.camera,
                player = engine.player,
                bots = engine.bots,
                tiger = engine.tiger,
                safeZone = engine.safeZone,
                buildings = engine.buildings,
                crates = engine.lootCrates,
                jumpPads = engine.jumpPads,
                projectiles = engine.projectiles,
                slashes = engine.slashes,
                floatingTexts = engine.floatingDamageTexts,
                animTimeSec = engine.animTimeSec
            )
        }

        // 2. Right Half Touch Surface for Camera Look / Aim
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.55f)
                .align(Alignment.CenterEnd)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        engine.camera.rotate(
                            deltaYaw = dragAmount.x * 0.35f,
                            deltaPitch = dragAmount.y * 0.25f
                        )
                    }
                }
        )

        // 3. HUD Overlay Layer
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top HUD Bar: Compass, Alive / Kill Count, Minimap
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                // Minimap & Location Tag
                Column(horizontalAlignment = Alignment.Start) {
                    MinimapView(engine = engine)
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = MidnightBlueDark.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ElectricGold)
                    ) {
                        Text(
                            text = "📍 Sangsad Bhaban Core",
                            color = ElectricGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Center Compass & Safe Zone Timer
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                ) {
                    CompassTape(yawDegrees = engine.camera.yawDegrees)
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = MidnightBlueDark.copy(alpha = 0.8f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = "Safe Zone",
                                tint = CyanAccent,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                "Safe Zone Phase ${engine.safeZone.phase}: ${engine.safeZone.timerSeconds.toInt()}s",
                                color = CyanAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Match Statistics: ALIVE & KILLS & Settings
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Alive Counter
                    Surface(
                        color = MidnightBlueLight.copy(alpha = 0.9f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ALIVE ", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${engine.alivePlayersCount}", color = CyanAccent, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    // Kill Counter
                    Surface(
                        color = MidnightBlueLight.copy(alpha = 0.9f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonAlert)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("KILL ", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${engine.playerKills}", color = CrimsonAlert, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    // Settings Button
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier
                            .size(34.dp)
                            .background(MidnightBlueDark.copy(alpha = 0.8f), CircleShape)
                            .border(1.dp, ElectricGold, CircleShape)
                            .testTag("game_settings_btn")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = ElectricGold, modifier = Modifier.size(18.dp))
                    }
                }
            }

            // Top Right Kill Feed
            if (engine.killFeed.isNotEmpty()) {
                Column(
                    modifier = Modifier.align(Alignment.End),
                    horizontalAlignment = Alignment.End
                ) {
                    engine.killFeed.take(3).forEach { kf ->
                        Surface(
                            color = ShadowBlack.copy(alpha = 0.75f),
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (kf.isHeadshot) CrimsonAlert else Color.DarkGray),
                            modifier = Modifier.padding(vertical = 1.dp)
                        ) {
                            Text(
                                text = "☠ ${kf.killer} [${kf.weaponName}] ${kf.victim}${if (kf.isHeadshot) " 🎯" else ""}",
                                color = if (kf.isHeadshot) CrimsonAlert else TextGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Quick Weapon Switch Bar & Jutsu Trigger
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Weapons Switcher
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(
                        WeaponRegistry.GOLD_KATANA,
                        WeaponRegistry.AK_BD,
                        WeaponRegistry.AWM_GOLD,
                        WeaponRegistry.SHURIKEN,
                        WeaponRegistry.GOLD_KATANA_ULTIMATE
                    ).forEach { weapon ->
                        val isEquipped = engine.player.equippedWeapon.id == weapon.id
                        Surface(
                            onClick = { engine.equipWeapon(weapon) },
                            color = if (isEquipped) ElectricGoldDark else MidnightBlueLight.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(if (isEquipped) 2.dp else 1.dp, if (isEquipped) ElectricGold else Color.Gray),
                            modifier = Modifier.height(38.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    when (weapon.category) {
                                        WeaponCategory.MELEE -> "⚔"
                                        WeaponCategory.FIREARM -> "🔫"
                                        WeaponCategory.THROWABLE -> "⭐"
                                        WeaponCategory.SPECIAL -> "✨"
                                    },
                                    fontSize = 12.sp
                                )
                                Text(
                                    weapon.name,
                                    color = if (isEquipped) ShadowBlack else TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // GK Jutsu Action Button
                Button(
                    onClick = onOpenGkJutsu,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldGreen,
                        contentColor = ShadowBlack
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(38.dp).testTag("bangla_gk_jutsu_btn")
                ) {
                    Text("⚡ BANGLA JUTSU", fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            }

            // Bottom Controls Layer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                // Left: Virtual Movement Joystick & Status Bars
                Column(
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Status Bars (HP, EP, Armor)
                    PlayerStatusBars(player = engine.player)

                    // Virtual Movement Joystick
                    VirtualJoystick(
                        onMove = { x, y ->
                            moveJoystickX = x
                            moveJoystickY = y
                        }
                    )
                }

                // Right: Action Combat Buttons (Slash/Fire, Jump, Crouch, Dash, Block)
                CombatActionControls(engine = engine)
            }
        }

        // 4. Booyah Victory / Defeat Overlays
        if (engine.matchState == MatchState.VICTORY_BOOYAH) {
            VictoryBooyahDialog(
                kills = engine.playerKills,
                timeSec = engine.survivalTimerSec.toInt(),
                onReturnToLobby = onReturnToLobby
            )
        } else if (engine.matchState == MatchState.DEFEAT) {
            DefeatDialog(
                kills = engine.playerKills,
                timeSec = engine.survivalTimerSec.toInt(),
                onRetry = { engine.initMatch() },
                onReturnToLobby = onReturnToLobby
            )
        }
    }
}

@Composable
private fun MinimapView(engine: GameEngine) {
    Box(
        modifier = Modifier
            .size(70.dp)
            .clip(CircleShape)
            .background(MidnightBlueDark.copy(alpha = 0.85f))
            .border(2.dp, ElectricGold, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val scale = 0.28f

            // Safe Zone Circle
            drawCircle(
                color = CyanAccent.copy(alpha = 0.4f),
                radius = (engine.safeZone.currentRadius * scale).coerceIn(4f, size.width / 2f - 4f),
                center = center,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
            )

            // Bots dots
            for (bot in engine.bots) {
                if (!bot.isEliminated) {
                    val relX = (bot.position.x - engine.player.position.x) * scale
                    val relZ = (bot.position.z - engine.player.position.z) * scale
                    if (hypot(relX, relZ) < size.width / 2f - 4f) {
                        drawCircle(
                            color = CrimsonAlert,
                            radius = 3f,
                            center = Offset(center.x + relX, center.y + relZ)
                        )
                    }
                }
            }

            // Player Dot (Center)
            drawCircle(
                color = ElectricGold,
                radius = 4.5f,
                center = center
            )
        }
    }
}

@Composable
private fun CompassTape(yawDegrees: Float) {
    Surface(
        color = MidnightBlueDark.copy(alpha = 0.85f),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, ElectricGoldDark)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val heading = when (((yawDegrees + 22.5f) % 360f / 45f).toInt()) {
                0 -> "N 0°"
                1 -> "NE 45°"
                2 -> "E 90°"
                3 -> "SE 135°"
                4 -> "S 180°"
                5 -> "SW 225°"
                6 -> "W 270°"
                else -> "NW 315°"
            }
            Text("NW 330", color = TextSecondary, fontSize = 9.sp)
            Text("345", color = TextSecondary, fontSize = 9.sp)
            Text(heading, color = ElectricGold, fontSize = 12.sp, fontWeight = FontWeight.Black)
            Text("15", color = TextSecondary, fontSize = 9.sp)
            Text("30 NE", color = TextSecondary, fontSize = 9.sp)
        }
    }
}

@Composable
private fun PlayerStatusBars(player: CharacterEntity) {
    Column(
        modifier = Modifier
            .width(170.dp)
            .background(ShadowBlack.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // HP Bar
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("HP ", color = EmeraldGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF1E3A28))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(player.health / player.maxHealth)
                        .background(EmeraldGreen)
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text("${player.health.toInt()}/${player.maxHealth.toInt()}", color = TextPrimary, fontSize = 9.sp)
        }

        // EP Bar (Energy Points for Jutsu & Dash)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("EP ", color = ElectricGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF3E3514))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(player.energyPoints / player.maxEnergyPoints)
                        .background(ElectricGold)
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text("${player.energyPoints.toInt()}/${player.maxEnergyPoints.toInt()}", color = TextPrimary, fontSize = 9.sp)
        }

        // Armor Bar
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("AP ", color = CyanAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF14303E))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(player.armor / player.maxArmor)
                        .background(CyanAccent)
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text("${player.armor.toInt()}/${player.maxArmor.toInt()}", color = TextPrimary, fontSize = 9.sp)
        }
    }
}

@Composable
private fun VirtualJoystick(onMove: (Float, Float) -> Unit) {
    var thumbOffset by remember { mutableStateOf(Offset.Zero) }
    val maxRadius = 45f

    Box(
        modifier = Modifier
            .size(110.dp)
            .clip(CircleShape)
            .background(MidnightBlueDark.copy(alpha = 0.6f))
            .border(2.dp, ElectricGold.copy(alpha = 0.5f), CircleShape)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = {
                        thumbOffset = Offset.Zero
                        onMove(0f, 0f)
                    },
                    onDragCancel = {
                        thumbOffset = Offset.Zero
                        onMove(0f, 0f)
                    }
                ) { change, dragAmount ->
                    change.consume()
                    val newOffset = thumbOffset + dragAmount
                    val dist = newOffset.getDistance()
                    thumbOffset = if (dist > maxRadius) {
                        newOffset * (maxRadius / dist)
                    } else {
                        newOffset
                    }
                    onMove(thumbOffset.x / maxRadius, -thumbOffset.y / maxRadius)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        // Center Thumb
        Box(
            modifier = Modifier
                .offset(thumbOffset.x.dp / 2.7f, thumbOffset.y.dp / 2.7f)
                .size(46.dp)
                .clip(CircleShape)
                .background(ElectricGold.copy(alpha = 0.85f))
                .border(2.dp, ShadowBlack, CircleShape)
        )
    }
}

@Composable
private fun CombatActionControls(engine: GameEngine) {
    Column(
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Upper Action Row: Shoulder Toggle, Sprint, Block
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Shoulder Toggle
            IconButton(
                onClick = { engine.camera.toggleShoulder() },
                modifier = Modifier
                    .size(42.dp)
                    .background(MidnightBlueLight.copy(alpha = 0.85f), CircleShape)
                    .border(1.dp, CyanAccent, CircleShape)
            ) {
                Icon(Icons.Default.Cameraswitch, contentDescription = "Shoulder Switch", tint = CyanAccent, modifier = Modifier.size(20.dp))
            }

            // Sprint Toggle
            IconButton(
                onClick = { engine.player.isSprinting = !engine.player.isSprinting },
                modifier = Modifier
                    .size(42.dp)
                    .background(if (engine.player.isSprinting) ElectricGold else MidnightBlueLight.copy(alpha = 0.85f), CircleShape)
                    .border(1.dp, ElectricGold, CircleShape)
            ) {
                Icon(
                    Icons.Default.DirectionsRun,
                    contentDescription = "Sprint",
                    tint = if (engine.player.isSprinting) ShadowBlack else ElectricGold,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Block / Parry
            IconButton(
                onClick = { engine.toggleBlock(!engine.player.isBlocking) },
                modifier = Modifier
                    .size(42.dp)
                    .background(if (engine.player.isBlocking) CyanAccent else MidnightBlueLight.copy(alpha = 0.85f), CircleShape)
                    .border(1.dp, CyanAccent, CircleShape)
            ) {
                Icon(
                    Icons.Default.Shield,
                    contentDescription = "Block Guard",
                    tint = if (engine.player.isBlocking) ShadowBlack else CyanAccent,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Lower Action Row: Crouch, Jump, Shadow Dash, Primary Attack (Big Button)
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            // Crouch / Slide
            IconButton(
                onClick = { engine.toggleCrouch() },
                modifier = Modifier
                    .size(48.dp)
                    .background(if (engine.player.isCrouching) ElectricGoldDark else MidnightBlueLight.copy(alpha = 0.85f), CircleShape)
                    .border(1.dp, ElectricGold, CircleShape)
                    .testTag("crouch_btn")
            ) {
                Text("🔻", fontSize = 18.sp)
            }

            // Jump
            IconButton(
                onClick = { engine.triggerJump() },
                modifier = Modifier
                    .size(52.dp)
                    .background(MidnightBlueLight.copy(alpha = 0.9f), CircleShape)
                    .border(2.dp, CyanAccent, CircleShape)
                    .testTag("jump_btn")
            ) {
                Icon(Icons.Default.ArrowUpward, contentDescription = "Jump", tint = CyanAccent, modifier = Modifier.size(26.dp))
            }

            // Shadow Dash
            IconButton(
                onClick = { engine.triggerShadowDash() },
                modifier = Modifier
                    .size(52.dp)
                    .background(MidnightBlueLight.copy(alpha = 0.9f), CircleShape)
                    .border(2.dp, ElectricGold, CircleShape)
                    .testTag("shadow_dash_btn")
            ) {
                Icon(Icons.Default.Bolt, contentDescription = "Shadow Dash", tint = ElectricGold, modifier = Modifier.size(28.dp))
            }

            // PRIMARY ATTACK / KATANA SLASH (Main Big Button)
            Button(
                onClick = { engine.triggerAttack() },
                modifier = Modifier
                    .size(72.dp)
                    .testTag("primary_attack_btn"),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ElectricGold,
                    contentColor = ShadowBlack
                ),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(
                    Icons.Default.FlashOn,
                    contentDescription = "Attack",
                    modifier = Modifier.size(36.dp),
                    tint = ShadowBlack
                )
            }
        }
    }
}

@Composable
private fun VictoryBooyahDialog(
    kills: Int,
    timeSec: Int,
    onReturnToLobby: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ShadowBlack.copy(alpha = 0.88f)),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 360.dp)
                .fillMaxWidth(0.85f),
            color = MidnightBlueDark,
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(3.dp, ElectricGold)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "🏆 BOOYAH! 🏆",
                    color = ElectricGold,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "#1 SHADOW LEGEND OF NEO DHAKA",
                    color = CyanAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Divider(color = ElectricGoldDark, thickness = 1.dp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Eliminations", color = TextSecondary, fontSize = 12.sp)
                        Text("$kills", color = CrimsonAlert, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Survival Time", color = TextSecondary, fontSize = 12.sp)
                        Text("${timeSec / 60}m ${timeSec % 60}s", color = TextGold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    }
                }

                Surface(
                    color = MidnightBlueLight,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "Match Reward: ৳ 2,500 Taka Earned!",
                        color = ElectricGold,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }

                Button(
                    onClick = onReturnToLobby,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricGold,
                        contentColor = ShadowBlack
                    )
                ) {
                    Text("RETURN TO LOBBY", fontWeight = FontWeight.Black, fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun DefeatDialog(
    kills: Int,
    timeSec: Int,
    onRetry: () -> Unit,
    onReturnToLobby: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ShadowBlack.copy(alpha = 0.88f)),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 360.dp)
                .fillMaxWidth(0.85f),
            color = MidnightBlueDark,
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(2.dp, CrimsonAlert)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "ELIMINATED",
                    color = CrimsonAlert,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )

                Text(
                    text = "Better luck next drop in Neo Dhaka!",
                    color = TextSecondary,
                    fontSize = 13.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Eliminations", color = TextSecondary, fontSize = 12.sp)
                        Text("$kills", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Survival Time", color = TextSecondary, fontSize = 12.sp)
                        Text("${timeSec / 60}m ${timeSec % 60}s", color = TextGold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onReturnToLobby,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TextSecondary)
                    ) {
                        Text("LOBBY", color = TextPrimary)
                    }

                    Button(
                        onClick = onRetry,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricGold,
                            contentColor = ShadowBlack
                        )
                    ) {
                        Text("RETRY", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
