package com.example.engine

import com.example.model.*
import kotlin.math.*
import kotlin.random.Random

enum class MatchState {
    LOBBY,
    COUNTDOWN,
    PLAYING,
    VICTORY_BOOYAH,
    DEFEAT
}

data class KillFeedEntry(
    val id: String,
    val killer: String,
    val victim: String,
    val weaponName: String,
    val isHeadshot: Boolean,
    val timestampMs: Long = System.currentTimeMillis()
)

class GameEngine(
    val audioManager: AudioManager
) {
    var matchState: MatchState = MatchState.PLAYING
    var alivePlayersCount: Int = 100
    var playerKills: Int = 0
    var survivalTimerSec: Float = 0f
    var animTimeSec: Float = 0f

    val player: CharacterEntity = CharacterEntity(
        id = "player_01",
        name = "ShadowNinja",
        position = Vector3(0f, 8.1f, 0f), // Spawned on top of Central Pavilion rooftop
        equippedWeapon = WeaponRegistry.GOLD_KATANA,
        activeSkin = SkinRegistry.SHADOW_DEFAULT
    )

    val camera: Camera3D = Camera3D(
        targetPosition = player.position,
        yawDegrees = 0f,
        pitchDegrees = 15f
    )

    val tiger: TigerCompanion = TigerCompanion()

    val safeZone: SafeZone = SafeZone(
        center = Vector3(0f, 0f, 0f),
        currentRadius = 180f,
        targetRadius = 40f,
        shrinkRatePerSec = 0.8f,
        phase = 1,
        timerSeconds = 180f,
        damagePerSecond = 6f
    )

    val buildings: List<Building3D> = NeoDhakaMap.TEST_ARENA_BUILDINGS
    val lootCrates: MutableList<LootCrate> = NeoDhakaMap.ARENA_LOOT_CRATES.toMutableList()
    val jumpPads: List<JumpPad> = NeoDhakaMap.ARENA_JUMP_PADS

    val bots: MutableList<CharacterEntity> = mutableListOf()
    val projectiles: MutableList<Projectile3D> = mutableListOf()
    val slashes: MutableList<SlashEffect3D> = mutableListOf()
    val floatingDamageTexts: MutableList<FloatingDamageText> = mutableListOf()
    val killFeed: MutableList<KillFeedEntry> = mutableListOf()

    val economy: PlayerEconomy = PlayerEconomy()

    private val botNames = listOf(
        "Mirpur_Kensei", "Gulistan_Tiger", "Dhanmondi_Ghost", "Curzon_Shinobi",
        "Uttara_Viper", "OldDhaka_Ronin", "Bhashani_Blade", "Shurjo_Ninja",
        "Rooftop_Reaper", "Moholla_Assassin", "Padma_Sniper", "Chittagong_Claw"
    )

    init {
        initMatch()
    }

    fun initMatch() {
        matchState = MatchState.PLAYING
        alivePlayersCount = 100
        playerKills = 0
        survivalTimerSec = 0f
        player.health = player.maxHealth
        player.armor = player.maxArmor
        player.stamina = player.maxStamina
        player.energyPoints = 150f
        player.isEliminated = false
        player.position = Vector3(0f, 8.1f, 0f)
        player.velocity = Vector3(0f, 0f, 0f)

        bots.clear()
        projectiles.clear()
        slashes.clear()
        floatingDamageTexts.clear()
        killFeed.clear()

        // Spawn initial bots in arena
        for (i in 0 until 12) {
            val name = botNames[i % botNames.size] + "_${Random.nextInt(10, 99)}"
            val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
            val dist = Random.nextFloat() * 70f + 15f
            val bx = cos(angle) * dist
            val bz = sin(angle) * dist
            val weapon = WeaponRegistry.ALL_21_WEAPONS.random()
            val skin = SkinRegistry.ALL_SKINS.random()

            bots.add(
                CharacterEntity(
                    id = "bot_$i",
                    name = name,
                    isBot = true,
                    position = Vector3(bx, 0f, bz),
                    equippedWeapon = weapon,
                    activeSkin = skin,
                    health = 180f,
                    maxHealth = 180f
                )
            )
        }
    }

    fun update(deltaTime: Float, moveInputX: Float, moveInputY: Float) {
        if (matchState != MatchState.PLAYING) return

        survivalTimerSec += deltaTime
        animTimeSec += deltaTime

        // 1. Update Player Movement & Physics
        updatePlayerPhysics(deltaTime, moveInputX, moveInputY)

        // 2. Update Camera
        camera.update(player.position + Vector3(0f, 1.4f, 0f), buildings, deltaTime)

        // 3. Update Tiger Companion
        updateTigerCompanion(deltaTime)

        // 4. Update Bots AI
        updateBots(deltaTime)

        // 5. Update Projectiles
        updateProjectiles(deltaTime)

        // 6. Update Slash VFX & Damage Numbers
        updateEffects(deltaTime)

        // 7. Update Safe Zone Shrink
        updateSafeZone(deltaTime)

        // 8. Simulated match eliminations across wide Neo Dhaka
        simulateBackgroundMatchEliminations(deltaTime)

        // 9. Check Victory or Defeat
        if (player.isEliminated) {
            matchState = MatchState.DEFEAT
            audioManager.playHitImpact()
        } else if (alivePlayersCount <= 1 && bots.all { it.isEliminated }) {
            matchState = MatchState.VICTORY_BOOYAH
            audioManager.playVictoryBooyah()
            economy.awardMatchEarnings(500, playerKills, isVictory = true)
        }
    }

    private fun updatePlayerPhysics(dt: Float, inputX: Float, inputY: Float) {
        val speed = when {
            player.isShadowCloaked -> 12f
            player.isSprinting -> 9.5f
            player.isCrouching -> 3.5f
            else -> 6.0f
        }

        // Camera-relative input movement
        val camFwd = camera.getForward()
        val camRight = camera.getRight()
        val moveDir = (camRight * inputX + camFwd * inputY).normalized()

        if (moveDir.length() > 0.01f) {
            player.velocity.x = moveDir.x * speed
            player.velocity.z = moveDir.z * speed
            player.yawDegrees = Math.toDegrees(atan2(moveDir.x.toDouble(), moveDir.z.toDouble())).toFloat()
            if (player.isGrounded) {
                player.animState = if (player.isSprinting) CharacterAnimationState.SPRINT else CharacterAnimationState.WALK
            }
        } else {
            player.velocity.x *= 0.6f
            player.velocity.z *= 0.6f
            if (player.isGrounded && player.animState != CharacterAnimationState.SLASH && player.animState != CharacterAnimationState.BLOCK) {
                player.animState = CharacterAnimationState.IDLE
            }
        }

        // Gravity
        if (!player.isGrounded) {
            player.velocity.y -= 26f * dt
            player.animState = if (player.velocity.y > 0) CharacterAnimationState.JUMP else CharacterAnimationState.FALL
        }

        val nextPos = player.position + player.velocity * dt

        // Collision with buildings & Rooftop walking
        var onRooftop = false
        var currentGroundY = 0f

        for (b in buildings) {
            val minX = b.position.x - b.width / 2f
            val maxX = b.position.x + b.width / 2f
            val minZ = b.position.z - b.depth / 2f
            val maxZ = b.position.z + b.depth / 2f
            val roofY = b.position.y + b.height

            if (nextPos.x in (minX - 0.5f)..(maxX + 0.5f) && nextPos.z in (minZ - 0.5f)..(maxZ + 0.5f)) {
                if (player.position.y >= roofY - 0.4f) {
                    // On top of building rooftop
                    onRooftop = true
                    currentGroundY = max(currentGroundY, roofY)
                } else {
                    // Horizontal wall collision: push back
                    player.velocity.x = 0f
                    player.velocity.z = 0f
                }
            }
        }

        if (nextPos.y <= currentGroundY) {
            nextPos.y = currentGroundY
            player.velocity.y = 0f
            player.isGrounded = true
        } else {
            player.isGrounded = false
        }

        player.position = nextPos

        // Check Jump Pads
        for (pad in jumpPads) {
            if (player.position.distance2D(pad.position) < 2.5f && player.position.y <= pad.position.y + 1f) {
                player.velocity.y = pad.launchForceY
                val fwd = player.velocity.normalized()
                player.velocity.x = fwd.x * pad.launchForward
                player.velocity.z = fwd.z * pad.launchForward
                player.isGrounded = false
                audioManager.playJump()
            }
        }

        // Check Loot Crate pickup
        for (crate in lootCrates) {
            if (!crate.isLooted && player.position.distanceTo(crate.position) < 3.2f) {
                // Auto pickup or upgrade weapon
                equipWeapon(crate.weapon)
                crate.isLooted = true
                economy.awardMatchEarnings(100, 0, false)
                audioManager.playKatanaSlash()
            }
        }

        // Stamina & Energy Regen
        player.stamina = (player.stamina + 15f * dt).coerceAtMost(player.maxStamina)
        player.energyPoints = (player.energyPoints + 5f * dt).coerceAtMost(player.maxEnergyPoints)

        // Shadow cloak duration
        if (player.isShadowCloaked) {
            player.cloakRemainingSeconds -= dt
            if (player.cloakRemainingSeconds <= 0f) {
                player.isShadowCloaked = false
            }
        }

        // Attack cooldown
        if (player.attackCooldown > 0f) {
            player.attackCooldown -= dt
        }
    }

    private fun updateTigerCompanion(dt: Float) {
        val targetPos = player.position - camera.getForward() * 2.2f + camera.getRight() * 1.5f
        val distToPlayer = tiger.position.distanceTo(player.position)

        if (distToPlayer > 20f) {
            // Teleport near player
            tiger.position = targetPos
        } else if (distToPlayer > 3.0f) {
            val dir = (targetPos - tiger.position).normalized()
            tiger.position = tiger.position + dir * 7.5f * dt
            tiger.currentState = PetState.FOLLOW
        } else {
            tiger.currentState = PetState.IDLE
        }

        // Tiger combat: leaps at closest hostile bot
        val closestBot = bots.filter { !it.isEliminated }.minByOrNull { it.position.distanceTo(tiger.position) }
        if (closestBot != null && closestBot.position.distanceTo(tiger.position) < 7f) {
            tiger.currentState = PetState.ATTACK
            val dir = (closestBot.position - tiger.position).normalized()
            tiger.position = tiger.position + dir * 9f * dt
            if (closestBot.position.distanceTo(tiger.position) < 2f) {
                closestBot.takeDamage(tiger.attackPower * dt)
                if (closestBot.isEliminated) {
                    onBotEliminated(closestBot, "Tiger [Sundarban Sher]", "Bite & Claw")
                }
            }
        }
    }

    private fun updateBots(dt: Float) {
        for (bot in bots) {
            if (bot.isEliminated) continue

            val distToPlayer = bot.position.distanceTo(player.position)
            if (distToPlayer < 25f && !player.isShadowCloaked) {
                // Approach player and attack
                val dir = (player.position - bot.position).normalized()
                bot.yawDegrees = Math.toDegrees(atan2(dir.x.toDouble(), dir.z.toDouble())).toFloat()

                if (distToPlayer > bot.equippedWeapon.rangeMeters * 0.8f) {
                    bot.position = bot.position + dir * 4.5f * dt
                    bot.animState = CharacterAnimationState.WALK
                } else {
                    // Bot attacks
                    bot.attackCooldown -= dt
                    if (bot.attackCooldown <= 0f) {
                        bot.attackCooldown = bot.equippedWeapon.attackCooldownSeconds * 1.5f
                        bot.animState = CharacterAnimationState.SLASH
                        val dmg = bot.equippedWeapon.damage * 0.4f // Balanced bot damage
                        player.takeDamage(dmg)
                        audioManager.playHitImpact()
                        floatingDamageTexts.add(
                            FloatingDamageText(
                                position = player.position + Vector3(0f, 1.8f, 0f),
                                damage = dmg,
                                isHeadshot = false
                            )
                        )
                    }
                }
            } else {
                // Idle wander
                bot.animState = CharacterAnimationState.IDLE
            }
        }
    }

    private fun updateProjectiles(dt: Float) {
        val iter = projectiles.iterator()
        while (iter.hasNext()) {
            val proj = iter.next()
            proj.position = proj.position + proj.velocity * dt
            proj.lifetimeSeconds -= dt

            // Check collision with bots
            var hit = false
            for (bot in bots) {
                if (!bot.isEliminated && bot.id != proj.senderId) {
                    val dist = proj.position.distanceTo(bot.position + Vector3(0f, 1.2f, 0f))
                    if (dist < 1.4f) {
                        val isHead = proj.position.y > bot.position.y + 1.5f
                        val dmg = bot.takeDamage(proj.weapon.damage, isHead)
                        audioManager.playHitImpact()
                        floatingDamageTexts.add(
                            FloatingDamageText(
                                position = bot.position + Vector3(0f, 2.0f, 0f),
                                damage = dmg,
                                isHeadshot = isHead
                            )
                        )
                        if (bot.isEliminated) {
                            playerKills++
                            onBotEliminated(bot, player.name, proj.weapon.name, isHead)
                        }
                        hit = true
                        break
                    }
                }
            }

            if (hit || proj.lifetimeSeconds <= 0f) {
                iter.remove()
            }
        }
    }

    private fun updateEffects(dt: Float) {
        slashes.removeAll {
            it.lifetimeSeconds -= dt
            it.lifetimeSeconds <= 0f
        }
        floatingDamageTexts.removeAll {
            it.lifetimeSeconds -= dt
            it.position.y += 1.2f * dt
            it.lifetimeSeconds <= 0f
        }
    }

    private fun updateSafeZone(dt: Float) {
        safeZone.timerSeconds -= dt
        if (safeZone.timerSeconds <= 0f) {
            safeZone.phase++
            safeZone.timerSeconds = 90f
            safeZone.targetRadius = max(20f, safeZone.currentRadius * 0.6f)
            safeZone.damagePerSecond += 3f
        }

        if (safeZone.currentRadius > safeZone.targetRadius) {
            safeZone.currentRadius -= safeZone.shrinkRatePerSec * dt
        }

        // Damage outside safe zone
        val playerDistFromCenter = player.position.distance2D(safeZone.center)
        if (playerDistFromCenter > safeZone.currentRadius) {
            player.takeDamage(safeZone.damagePerSecond * dt)
        }

        for (bot in bots) {
            if (!bot.isEliminated && bot.position.distance2D(safeZone.center) > safeZone.currentRadius) {
                bot.takeDamage(safeZone.damagePerSecond * dt)
                if (bot.isEliminated) {
                    onBotEliminated(bot, "Safe Zone", "Zone Damage")
                }
            }
        }
    }

    private fun simulateBackgroundMatchEliminations(dt: Float) {
        // Random background eliminations across the 8000x8000 Neo Dhaka region to decrement alive players to final circle
        if (alivePlayersCount > bots.count { !it.isEliminated } + 1 && Random.nextFloat() < 0.15f * dt) {
            alivePlayersCount--
            val killer = botNames.random()
            val victim = botNames.random()
            val weapon = WeaponRegistry.ALL_21_WEAPONS.random().name
            killFeed.add(
                0,
                KillFeedEntry(
                    id = "bg_${System.currentTimeMillis()}",
                    killer = killer,
                    victim = victim,
                    weaponName = weapon,
                    isHeadshot = Random.nextBoolean()
                )
            )
            if (killFeed.size > 5) killFeed.removeLast()
        }
    }

    private fun onBotEliminated(bot: CharacterEntity, killer: String, weaponName: String, isHeadshot: Boolean = false) {
        alivePlayersCount = max(1, alivePlayersCount - 1)
        killFeed.add(
            0,
            KillFeedEntry(
                id = "kf_${System.currentTimeMillis()}",
                killer = killer,
                victim = bot.name,
                weaponName = weaponName,
                isHeadshot = isHeadshot
            )
        )
        if (killFeed.size > 5) killFeed.removeLast()
        economy.awardMatchEarnings(150, 1, false)
    }

    // Player Actions
    fun triggerAttack() {
        if (player.attackCooldown > 0f || player.isEliminated) return
        player.attackCooldown = player.equippedWeapon.attackCooldownSeconds

        when (player.equippedWeapon.category) {
            WeaponCategory.MELEE -> performMeleeAttack()
            WeaponCategory.THROWABLE -> performThrowableAttack()
            WeaponCategory.FIREARM -> performFirearmAttack()
            WeaponCategory.SPECIAL -> performSpecialGadget()
        }
    }

    private fun performMeleeAttack() {
        player.animState = CharacterAnimationState.SLASH
        audioManager.playKatanaSlash()

        val isGoldUlt = player.equippedWeapon.id == "gold_katana_ultimate"
        val fwd = camera.getForward()
        val slashOrigin = player.position + Vector3(0f, 1.2f, 0f) + fwd * 0.8f

        slashes.add(
            SlashEffect3D(
                origin = slashOrigin,
                direction = fwd,
                isGoldUltimate = isGoldUlt
            )
        )

        // Hit detection in melee cone
        for (bot in bots) {
            if (!bot.isEliminated) {
                val dist = player.position.distanceTo(bot.position)
                if (dist <= player.equippedWeapon.rangeMeters) {
                    val toBot = (bot.position - player.position).normalized()
                    val dot = fwd.dot(toBot)
                    if (dot > 0.4f) { // In front of player
                        val dmg = bot.takeDamage(player.equippedWeapon.damage)
                        audioManager.playHitImpact()
                        floatingDamageTexts.add(
                            FloatingDamageText(
                                position = bot.position + Vector3(0f, 1.8f, 0f),
                                damage = dmg,
                                isHeadshot = false
                            )
                        )
                        if (bot.isEliminated) {
                            playerKills++
                            onBotEliminated(bot, player.name, player.equippedWeapon.name)
                        }
                    }
                }
            }
        }
    }

    private fun performFirearmAttack() {
        player.animState = CharacterAnimationState.SHOOT
        audioManager.playGunshot()

        val fwd = camera.getForward()
        val startPos = player.position + Vector3(0f, 1.4f, 0f) + fwd * 0.5f
        projectiles.add(
            Projectile3D(
                position = startPos,
                velocity = fwd * 60f,
                weapon = player.equippedWeapon,
                senderId = player.id
            )
        )
    }

    private fun performThrowableAttack() {
        val fwd = camera.getForward()
        val startPos = player.position + Vector3(0f, 1.4f, 0f) + fwd * 0.5f

        if (player.equippedWeapon.id == "shuriken") {
            // 3-way spread
            val right = camera.getRight()
            projectiles.add(Projectile3D(startPos, (fwd + right * 0.25f).normalized() * 30f, player.equippedWeapon, player.id))
            projectiles.add(Projectile3D(startPos, fwd * 30f, player.equippedWeapon, player.id))
            projectiles.add(Projectile3D(startPos, (fwd - right * 0.25f).normalized() * 30f, player.equippedWeapon, player.id))
        } else {
            projectiles.add(Projectile3D(startPos, fwd * 35f, player.equippedWeapon, player.id))
        }
        audioManager.playKatanaSlash()
    }

    private fun performSpecialGadget() {
        if (player.equippedWeapon.id == "shadow_cloak") {
            player.isShadowCloaked = true
            player.cloakRemainingSeconds = 5.0f
            audioManager.playKatanaSlash()
        } else {
            performMeleeAttack()
        }
    }

    fun triggerJump() {
        if (player.isGrounded && !player.isEliminated) {
            player.velocity.y = 13.5f
            player.isGrounded = false
            player.animState = CharacterAnimationState.JUMP
            audioManager.playJump()
        }
    }

    fun triggerShadowDash() {
        if (player.energyPoints >= 25f && !player.isEliminated) {
            player.energyPoints -= 25f
            val fwd = camera.getForward()
            player.position = player.position + fwd * 8.0f
            audioManager.playKatanaSlash()
        }
    }

    fun toggleCrouch() {
        player.isCrouching = !player.isCrouching
    }

    fun toggleBlock(blocking: Boolean) {
        player.isBlocking = blocking
        player.animState = if (blocking) CharacterAnimationState.BLOCK else CharacterAnimationState.IDLE
    }

    fun equipWeapon(weapon: WeaponData) {
        player.equippedWeapon = weapon
    }
}
