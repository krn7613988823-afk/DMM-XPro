package com.example.engine

import android.graphics.Paint
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import com.example.model.*
import kotlin.math.*

data class Projectile3D(
    var position: Vector3,
    val velocity: Vector3,
    val weapon: WeaponData,
    val senderId: String,
    var lifetimeSeconds: Float = 3f,
    val isHeadshot: Boolean = false
)

data class SlashEffect3D(
    val origin: Vector3,
    val direction: Vector3,
    var lifetimeSeconds: Float = 0.35f,
    val maxLifetime: Float = 0.35f,
    val isGoldUltimate: Boolean = false
)

data class FloatingDamageText(
    var position: Vector3,
    val damage: Float,
    val isHeadshot: Boolean,
    var lifetimeSeconds: Float = 1.0f
)

class Renderer3D {
    // Screen projection math
    private fun projectToScreen(
        worldPos: Vector3,
        camera: Camera3D,
        screenWidth: Float,
        screenHeight: Float,
        fovDeg: Float = 60f
    ): ScreenPoint? {
        // Translate world pos relative to camera
        val relPos = worldPos - camera.position

        val yawRad = Math.toRadians(-camera.yawDegrees.toDouble()).toFloat()
        val pitchRad = Math.toRadians(-camera.pitchDegrees.toDouble()).toFloat()

        // Rotate around Y axis (Yaw)
        val cosY = cos(yawRad)
        val sinY = sin(yawRad)
        val x1 = relPos.x * cosY - relPos.z * sinY
        val z1 = relPos.x * sinY + relPos.z * cosY
        val y1 = relPos.y

        // Rotate around X axis (Pitch)
        val cosP = cos(pitchRad)
        val sinP = sin(pitchRad)
        val y2 = y1 * cosP - z1 * sinP
        val z2 = y1 * sinP + z1 * cosP
        val x2 = x1

        // Near plane clipping
        if (z2 <= 0.2f) return null

        val fovRad = Math.toRadians(fovDeg.toDouble()).toFloat()
        val fovScale = (screenHeight / 2f) / tan(fovRad / 2f)

        val screenX = screenWidth / 2f + (x2 / z2) * fovScale
        val screenY = screenHeight / 2f - (y2 / z2) * fovScale

        return ScreenPoint(screenX, screenY, z2)
    }

    data class ScreenPoint(val x: Float, val y: Float, val depth: Float)

    fun renderScene(
        scope: DrawScope,
        camera: Camera3D,
        player: CharacterEntity,
        bots: List<CharacterEntity>,
        tiger: TigerCompanion?,
        safeZone: SafeZone,
        buildings: List<Building3D>,
        crates: List<LootCrate>,
        jumpPads: List<JumpPad>,
        projectiles: List<Projectile3D>,
        slashes: List<SlashEffect3D>,
        floatingTexts: List<FloatingDamageText>,
        animTimeSec: Float
    ) {
        val w = scope.size.width
        val h = scope.size.height

        // 1. Sky & Neo Dhaka Night Gradient
        scope.drawRect(
            color = Color(0xFF040812),
            size = scope.size
        )

        // Distant atmospheric horizon glow
        val horizonPt = projectToScreen(Vector3(0f, 0f, 500f), camera, w, h)
        val horizonY = horizonPt?.y ?: (h * 0.45f)
        scope.drawRect(
            color = Color(0xFF0A1C36),
            topLeft = Offset(0f, horizonY.coerceIn(0f, h * 0.7f)),
            size = androidx.compose.ui.geometry.Size(w, h)
        )

        // 2. Neo Dhaka Grid Floor (streets and district layout)
        drawGroundGrid(scope, camera, w, h)

        // 3. Render 3D Buildings
        for (b in buildings) {
            drawBuilding(scope, b, camera, w, h)
        }

        // 4. Render Jump Pads
        for (pad in jumpPads) {
            drawJumpPad(scope, pad, camera, w, h, animTimeSec)
        }

        // 5. Render Loot Crates
        for (crate in crates) {
            if (!crate.isLooted) {
                drawLootCrate(scope, crate, camera, w, h, animTimeSec)
            }
        }

        // 6. Safe Zone Barrier
        drawSafeZoneBarrier(scope, safeZone, camera, w, h, animTimeSec)

        // 7. Render Bots
        for (bot in bots) {
            if (!bot.isEliminated) {
                drawNinjaCharacter(scope, bot, camera, w, h, animTimeSec, isPlayer = false)
            }
        }

        // 8. Render Player Ninja
        drawNinjaCharacter(scope, player, camera, w, h, animTimeSec, isPlayer = true)

        // 9. Render Tiger Companion
        if (tiger != null) {
            drawTigerCompanion(scope, tiger, camera, w, h, animTimeSec)
        }

        // 10. Render Slashes and Projectiles
        for (slash in slashes) {
            drawSlashEffect(scope, slash, camera, w, h)
        }
        for (proj in projectiles) {
            drawProjectile(scope, proj, camera, w, h)
        }

        // 11. Render Floating Damage Numbers
        for (dmg in floatingTexts) {
            drawFloatingDamage(scope, dmg, camera, w, h)
        }
    }

    private fun drawGroundGrid(scope: DrawScope, camera: Camera3D, w: Float, h: Float) {
        val gridSize = 10f
        val range = 60f
        val camX = (camera.position.x / gridSize).toInt() * gridSize
        val camZ = (camera.position.z / gridSize).toInt() * gridSize

        for (x in -6..6) {
            val worldX = camX + x * gridSize
            val p1 = projectToScreen(Vector3(worldX, 0f, camZ - range), camera, w, h)
            val p2 = projectToScreen(Vector3(worldX, 0f, camZ + range), camera, w, h)
            if (p1 != null && p2 != null) {
                val alpha = (1f - (abs(x * gridSize) / range)).coerceIn(0.05f, 0.3f)
                scope.drawLine(
                    color = Color(0xFF1E3A5F).copy(alpha = alpha),
                    start = Offset(p1.x, p1.y),
                    end = Offset(p2.x, p2.y),
                    strokeWidth = 1.5f
                )
            }
        }

        for (z in -6..6) {
            val worldZ = camZ + z * gridSize
            val p1 = projectToScreen(Vector3(camX - range, 0f, worldZ), camera, w, h)
            val p2 = projectToScreen(Vector3(camX + range, 0f, worldZ), camera, w, h)
            if (p1 != null && p2 != null) {
                val alpha = (1f - (abs(z * gridSize) / range)).coerceIn(0.05f, 0.3f)
                scope.drawLine(
                    color = Color(0xFF1E3A5F).copy(alpha = alpha),
                    start = Offset(p1.x, p1.y),
                    end = Offset(p2.x, p2.y),
                    strokeWidth = 1.5f
                )
            }
        }
    }

    private fun drawBuilding(scope: DrawScope, b: Building3D, camera: Camera3D, w: Float, h: Float) {
        val hw = b.width / 2f
        val hd = b.depth / 2f
        val bx = b.position.x
        val by = b.position.y
        val bz = b.position.z
        val bh = b.height

        // 8 Corners of the building
        val c0 = projectToScreen(Vector3(bx - hw, by, bz - hd), camera, w, h)
        val c1 = projectToScreen(Vector3(bx + hw, by, bz - hd), camera, w, h)
        val c2 = projectToScreen(Vector3(bx + hw, by, bz + hd), camera, w, h)
        val c3 = projectToScreen(Vector3(bx - hw, by, bz + hd), camera, w, h)

        val t0 = projectToScreen(Vector3(bx - hw, by + bh, bz - hd), camera, w, h)
        val t1 = projectToScreen(Vector3(bx + hw, by + bh, bz - hd), camera, w, h)
        val t2 = projectToScreen(Vector3(bx + hw, by + bh, bz + hd), camera, w, h)
        val t3 = projectToScreen(Vector3(bx - hw, by + bh, bz + hd), camera, w, h)

        val baseColor = Color(b.colorHex)

        // Draw rooftop if visible
        if (t0 != null && t1 != null && t2 != null && t3 != null) {
            val roofPath = Path().apply {
                moveTo(t0.x, t0.y)
                lineTo(t1.x, t1.y)
                lineTo(t2.x, t2.y)
                lineTo(t3.x, t3.y)
                close()
            }
            scope.drawPath(roofPath, color = baseColor.copy(alpha = 0.9f), style = Fill)
            scope.drawPath(roofPath, color = Color(0xFFFFD700).copy(alpha = 0.6f), style = Stroke(width = 2.5f))
        }

        // Front Face (t0, t1, c1, c0)
        if (t0 != null && t1 != null && c1 != null && c0 != null) {
            val wallPath = Path().apply {
                moveTo(c0.x, c0.y)
                lineTo(t0.x, t0.y)
                lineTo(t1.x, t1.y)
                lineTo(c1.x, c1.y)
                close()
            }
            scope.drawPath(wallPath, color = baseColor.copy(alpha = 0.75f), style = Fill)
            scope.drawPath(wallPath, color = Color(0xFF1E3A5F), style = Stroke(width = 1.5f))
        }

        // Side Face (t1, t2, c2, c1)
        if (t1 != null && t2 != null && c2 != null && c1 != null) {
            val wallPath = Path().apply {
                moveTo(c1.x, c1.y)
                lineTo(t1.x, t1.y)
                lineTo(t2.x, t2.y)
                lineTo(c2.x, c2.y)
                close()
            }
            scope.drawPath(wallPath, color = baseColor.copy(alpha = 0.65f), style = Fill)
            scope.drawPath(wallPath, color = Color(0xFF1E3A5F), style = Stroke(width = 1.5f))
        }
    }

    private fun drawJumpPad(scope: DrawScope, pad: JumpPad, camera: Camera3D, w: Float, h: Float, animTime: Float) {
        val pt = projectToScreen(pad.position, camera, w, h) ?: return
        val pulse = 1f + 0.2f * sin(animTime * 6f)
        val radius = (20f / pt.depth.coerceAtLeast(1f) * 15f) * pulse

        scope.drawCircle(
            color = Color(0xFFFFD700).copy(alpha = 0.3f),
            radius = radius * 1.4f,
            center = Offset(pt.x, pt.y)
        )
        scope.drawCircle(
            color = Color(0xFFFFD700),
            radius = radius,
            center = Offset(pt.x, pt.y),
            style = Stroke(width = 3f)
        )
        scope.drawCircle(
            color = Color(0xFF00E5FF),
            radius = radius * 0.5f,
            center = Offset(pt.x, pt.y)
        )
    }

    private fun drawLootCrate(scope: DrawScope, crate: LootCrate, camera: Camera3D, w: Float, h: Float, animTime: Float) {
        val pt = projectToScreen(crate.position + Vector3(0f, 0.4f + 0.1f * sin(animTime * 3f), 0f), camera, w, h) ?: return
        val size = (35f / pt.depth.coerceAtLeast(1f) * 12f).coerceIn(12f, 70f)

        // Golden Crate Box
        scope.drawRect(
            color = Color(0xFFFFD700),
            topLeft = Offset(pt.x - size / 2f, pt.y - size / 2f),
            size = androidx.compose.ui.geometry.Size(size, size)
        )
        scope.drawRect(
            color = Color(0xFF0A1931),
            topLeft = Offset(pt.x - size / 2f, pt.y - size / 2f),
            size = androidx.compose.ui.geometry.Size(size, size),
            style = Stroke(width = 2.5f)
        )

        // Weapon label above crate
        if (pt.depth < 30f) {
            val paint = Paint().apply {
                color = android.graphics.Color.YELLOW
                textSize = (13f * 2.5f).coerceIn(18f, 32f)
                textAlign = Paint.Align.CENTER
                isFakeBoldText = true
            }
            scope.drawContext.canvas.nativeCanvas.drawText(
                "⚡ ${crate.weapon.name}",
                pt.x,
                pt.y - size * 0.8f,
                paint
            )
        }
    }

    private fun drawSafeZoneBarrier(scope: DrawScope, safeZone: SafeZone, camera: Camera3D, w: Float, h: Float, animTime: Float) {
        val segments = 24
        val points = mutableListOf<ScreenPoint>()
        for (i in 0 until segments) {
            val angle = (i.toFloat() / segments) * 2f * Math.PI.toFloat()
            val wx = safeZone.center.x + safeZone.currentRadius * cos(angle)
            val wz = safeZone.center.z + safeZone.currentRadius * sin(angle)
            val pt = projectToScreen(Vector3(wx, 0f, wz), camera, w, h)
            if (pt != null) {
                points.add(pt)
            }
        }

        // Draw ring boundary
        for (i in 0 until points.size - 1) {
            scope.drawLine(
                color = Color(0xFF00E5FF).copy(alpha = 0.7f + 0.2f * sin(animTime * 4f)),
                start = Offset(points[i].x, points[i].y),
                end = Offset(points[i + 1].x, points[i + 1].y),
                strokeWidth = 3f
            )
        }
    }

    private fun drawNinjaCharacter(
        scope: DrawScope,
        char: CharacterEntity,
        camera: Camera3D,
        w: Float,
        h: Float,
        animTime: Float,
        isPlayer: Boolean
    ) {
        val basePos = char.position
        val headPt = projectToScreen(basePos + Vector3(0f, 1.75f, 0f), camera, w, h) ?: return
        val torsoPt = projectToScreen(basePos + Vector3(0f, 1.1f, 0f), camera, w, h) ?: return
        val feetPt = projectToScreen(basePos + Vector3(0f, 0.05f, 0f), camera, w, h) ?: return

        val depth = torsoPt.depth.coerceAtLeast(0.5f)
        val charHeightOnScreen = abs(feetPt.y - headPt.y).coerceIn(20f, 300f)
        val scale = charHeightOnScreen / 80f

        val skin = char.activeSkin
        val clothColor = if (char.isShadowCloaked) Color(0x669C27B0) else Color(skin.primaryColorHex)
        val accentGold = if (char.isShadowCloaked) Color(0xAA00E5FF) else Color(skin.accentColorHex)

        // Animation Bob & offsets
        val isMoving = char.velocity.length() > 0.5f
        val stride = if (isMoving) sin(animTime * if (char.isSprinting) 14f else 8f) else 0f
        val crouchOffset = if (char.isCrouching) 15f * scale else 0f

        // 1. Shadow beneath character
        val shadowWidth = 18f * scale
        val shadowHeight = 6f * scale
        scope.drawOval(
            color = Color(0x77000000),
            topLeft = Offset(feetPt.x - shadowWidth / 2f, feetPt.y - shadowHeight / 2f),
            size = androidx.compose.ui.geometry.Size(shadowWidth, shadowHeight)
        )

        // 2. Legs / Lower Body (Tactical Pants or Lungi/Gamcha)
        val hipY = torsoPt.y + 12f * scale + crouchOffset
        val legLeftX = torsoPt.x - 6f * scale + stride * 4f * scale
        val legRightX = torsoPt.x + 6f * scale - stride * 4f * scale

        // Left Leg
        scope.drawLine(
            color = clothColor,
            start = Offset(torsoPt.x - 4f * scale, hipY),
            end = Offset(legLeftX, feetPt.y),
            strokeWidth = 7f * scale
        )
        // Right Leg
        scope.drawLine(
            color = clothColor,
            start = Offset(torsoPt.x + 4f * scale, hipY),
            end = Offset(legRightX, feetPt.y),
            strokeWidth = 7f * scale
        )

        // Tactical ninja leg wraps / Gold Shin Guards
        scope.drawLine(
            color = accentGold,
            start = Offset(legLeftX, feetPt.y - 8f * scale),
            end = Offset(legLeftX, feetPt.y - 2f * scale),
            strokeWidth = 6f * scale
        )
        scope.drawLine(
            color = accentGold,
            start = Offset(legRightX, feetPt.y - 8f * scale),
            end = Offset(legRightX, feetPt.y - 2f * scale),
            strokeWidth = 6f * scale
        )

        // 3. Torso & Tactical Armor Plate
        val torsoWidth = 16f * scale
        val torsoHeight = 22f * scale
        val torsoTopY = torsoPt.y - torsoHeight / 2f + crouchOffset

        // Main Torso Armor
        scope.drawRect(
            color = clothColor,
            topLeft = Offset(torsoPt.x - torsoWidth / 2f, torsoTopY),
            size = androidx.compose.ui.geometry.Size(torsoWidth, torsoHeight)
        )

        // Tactical Gold Chest Harness / Emblems
        scope.drawLine(
            color = accentGold,
            start = Offset(torsoPt.x - torsoWidth / 2f, torsoTopY + 4f * scale),
            end = Offset(torsoPt.x + torsoWidth / 2f, torsoTopY + torsoHeight - 4f * scale),
            strokeWidth = 3f * scale
        )
        scope.drawLine(
            color = accentGold,
            start = Offset(torsoPt.x + torsoWidth / 2f, torsoTopY + 4f * scale),
            end = Offset(torsoPt.x - torsoWidth / 2f, torsoTopY + torsoHeight - 4f * scale),
            strokeWidth = 3f * scale
        )

        // 4. Arms & Weapons
        val armLeftX = torsoPt.x - torsoWidth / 2f - 4f * scale
        val armRightX = torsoPt.x + torsoWidth / 2f + 4f * scale
        val armY = torsoTopY + 6f * scale

        // Attack or Block posture
        val isAttacking = char.animState == CharacterAnimationState.SLASH || char.animState == CharacterAnimationState.PUNCH
        val slashSwing = if (isAttacking) sin(animTime * 25f) * 15f * scale else 0f

        // Left arm
        scope.drawLine(
            color = clothColor,
            start = Offset(armLeftX, armY),
            end = Offset(armLeftX - 4f * scale, armY + 16f * scale),
            strokeWidth = 6f * scale
        )

        // Right arm holding weapon
        val handRightX = armRightX + 4f * scale + slashSwing
        val handRightY = armY + (if (char.isBlocking) -4f * scale else 12f * scale)
        scope.drawLine(
            color = clothColor,
            start = Offset(armRightX, armY),
            end = Offset(handRightX, handRightY),
            strokeWidth = 6f * scale
        )

        // Render Held Weapon (e.g. Katana blade or Gun)
        if (char.equippedWeapon.category == WeaponCategory.MELEE || char.equippedWeapon.id.contains("katana")) {
            // Katana Blade
            val bladeLength = 26f * scale
            val bladeColor = if (char.equippedWeapon.id == "gold_katana_ultimate") Color(0xFFFFD700) else Color(0xFFE0E0E0)
            val hiltColor = Color(0xFFFFD700)

            // Blade slant
            val bladeEndX = handRightX + if (char.isBlocking) -18f * scale else 16f * scale
            val bladeEndY = handRightY - if (char.isBlocking) 16f * scale else bladeLength

            // Glowing Edge
            scope.drawLine(
                color = bladeColor,
                start = Offset(handRightX, handRightY),
                end = Offset(bladeEndX, bladeEndY),
                strokeWidth = 3.5f * scale
            )
            // Hilt
            scope.drawCircle(
                color = hiltColor,
                radius = 3.5f * scale,
                center = Offset(handRightX, handRightY)
            )
        } else if (char.equippedWeapon.category == WeaponCategory.FIREARM) {
            // Firearm Barrel
            scope.drawLine(
                color = Color(0xFF212121),
                start = Offset(handRightX, handRightY),
                end = Offset(handRightX + 18f * scale, handRightY - 4f * scale),
                strokeWidth = 4f * scale
            )
        }

        // 5. Tactical Backpack & Back Sheath
        scope.drawRect(
            color = Color(0xFF0F1A28),
            topLeft = Offset(torsoPt.x - 5f * scale, torsoTopY + 2f * scale),
            size = androidx.compose.ui.geometry.Size(10f * scale, 14f * scale)
        )
        // Crossed Katana Sheaths on Back
        scope.drawLine(
            color = Color(0xFFFFD700),
            start = Offset(torsoPt.x - 10f * scale, torsoTopY - 4f * scale),
            end = Offset(torsoPt.x + 8f * scale, torsoTopY + 16f * scale),
            strokeWidth = 2.5f * scale
        )

        // 6. Ninja Head & Hood Cowl
        val headRadius = 9f * scale
        val headCenterY = headPt.y + headRadius + crouchOffset
        scope.drawCircle(
            color = clothColor,
            radius = headRadius,
            center = Offset(headPt.x, headCenterY)
        )

        // Glowing Gold Eyes slit
        val eyeWidth = 4.5f * scale
        val eyeHeight = 2.0f * scale
        val eyeY = headCenterY - 1f * scale
        scope.drawOval(
            color = Color(0xFFFFD700),
            topLeft = Offset(headPt.x - 5f * scale, eyeY),
            size = androidx.compose.ui.geometry.Size(eyeWidth, eyeHeight)
        )
        scope.drawOval(
            color = Color(0xFFFFD700),
            topLeft = Offset(headPt.x + 1f * scale, eyeY),
            size = androidx.compose.ui.geometry.Size(eyeWidth, eyeHeight)
        )
        // Gold eye gleam
        scope.drawCircle(
            color = Color(0xFFFFF59D),
            radius = 1.2f * scale,
            center = Offset(headPt.x - 3f * scale, eyeY + 1f * scale)
        )
        scope.drawCircle(
            color = Color(0xFFFFF59D),
            radius = 1.2f * scale,
            center = Offset(headPt.x + 3f * scale, eyeY + 1f * scale)
        )

        // 7. Nameplate & Health Bar above character
        if (depth < 40f) {
            val nameplateY = headPt.y - 12f * scale
            val barWidth = 44f * scale
            val barHeight = 4.5f * scale

            // Health Bar Background
            scope.drawRect(
                color = Color(0xAA000000),
                topLeft = Offset(headPt.x - barWidth / 2f, nameplateY),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
            )

            // Health Bar Progress
            val hpRatio = (char.health / char.maxHealth).coerceIn(0f, 1f)
            val hpColor = if (hpRatio > 0.5f) Color(0xFF00E676) else if (hpRatio > 0.2f) Color(0xFFFFD700) else Color(0xFFE63946)
            scope.drawRect(
                color = hpColor,
                topLeft = Offset(headPt.x - barWidth / 2f, nameplateY),
                size = androidx.compose.ui.geometry.Size(barWidth * hpRatio, barHeight)
            )

            // Name text
            val paint = Paint().apply {
                color = if (isPlayer) android.graphics.Color.YELLOW else android.graphics.Color.RED
                textSize = (11f * 2.2f * scale).coerceIn(16f, 30f)
                textAlign = Paint.Align.CENTER
                isFakeBoldText = true
            }
            scope.drawContext.canvas.nativeCanvas.drawText(
                if (isPlayer) "⚡ ${char.name}" else "☠ ${char.name}",
                headPt.x,
                nameplateY - 6f,
                paint
            )
        }
    }

    private fun drawTigerCompanion(
        scope: DrawScope,
        tiger: TigerCompanion,
        camera: Camera3D,
        w: Float,
        h: Float,
        animTime: Float
    ) {
        val pt = projectToScreen(tiger.position, camera, w, h) ?: return
        val depth = pt.depth.coerceAtLeast(0.5f)
        val scale = (45f / depth).coerceIn(0.5f, 3.5f)

        val tigerColor = when (tiger.evolution) {
            TigerEvolution.ROYAL_BENGAL -> Color(0xFFE65100)
            TigerEvolution.ARMORED_TIGER -> Color(0xFF546E7A)
            TigerEvolution.GOLDEN_TIGER -> Color(0xFFFFD700)
        }

        // Tiger Body
        scope.drawOval(
            color = tigerColor,
            topLeft = Offset(pt.x - 14f * scale, pt.y - 10f * scale),
            size = androidx.compose.ui.geometry.Size(28f * scale, 16f * scale)
        )

        // Tiger Stripes
        for (i in -1..1) {
            scope.drawLine(
                color = Color(0xFF1A1A1A),
                start = Offset(pt.x + i * 6f * scale, pt.y - 10f * scale),
                end = Offset(pt.x + i * 6f * scale, pt.y),
                strokeWidth = 2.5f * scale
            )
        }

        // Tiger Head
        val headX = pt.x + 14f * scale
        val headY = pt.y - 6f * scale
        scope.drawCircle(
            color = tigerColor,
            radius = 8f * scale,
            center = Offset(headX, headY)
        )

        // Glowing Eyes
        scope.drawCircle(
            color = Color(0xFFFFD700),
            radius = 2f * scale,
            center = Offset(headX + 4f * scale, headY - 2f * scale)
        )

        // Tail
        scope.drawLine(
            color = tigerColor,
            start = Offset(pt.x - 14f * scale, pt.y - 4f * scale),
            end = Offset(pt.x - 22f * scale, pt.y - 12f * scale + 3f * sin(animTime * 6f) * scale),
            strokeWidth = 3.5f * scale
        )

        // Tiger Name & Level
        if (depth < 35f) {
            val paint = Paint().apply {
                color = android.graphics.Color.rgb(255, 215, 0)
                textSize = (10f * 2.2f * scale).coerceIn(14f, 24f)
                textAlign = Paint.Align.CENTER
                isFakeBoldText = true
            }
            scope.drawContext.canvas.nativeCanvas.drawText(
                "🐯 ${tiger.name} [Lv.${tiger.level}]",
                pt.x,
                pt.y - 18f * scale,
                paint
            )
        }
    }

    private fun drawSlashEffect(scope: DrawScope, slash: SlashEffect3D, camera: Camera3D, w: Float, h: Float) {
        val p1 = projectToScreen(slash.origin, camera, w, h) ?: return
        val p2 = projectToScreen(slash.origin + slash.direction * 3.5f, camera, w, h) ?: return

        val alpha = (slash.lifetimeSeconds / slash.maxLifetime).coerceIn(0f, 1f)
        val slashColor = if (slash.isGoldUltimate) Color(0xFFFFD700) else Color(0xFF00E5FF)

        scope.drawLine(
            color = slashColor.copy(alpha = alpha),
            start = Offset(p1.x, p1.y),
            end = Offset(p2.x, p2.y),
            strokeWidth = 6f
        )
    }

    private fun drawProjectile(scope: DrawScope, proj: Projectile3D, camera: Camera3D, w: Float, h: Float) {
        val pt = projectToScreen(proj.position, camera, w, h) ?: return
        val trailPt = projectToScreen(proj.position - proj.velocity.normalized() * 1.5f, camera, w, h)

        val color = when (proj.weapon.category) {
            WeaponCategory.FIREARM -> Color(0xFFFFD54F)
            WeaponCategory.THROWABLE -> Color(0xFF00E5FF)
            else -> Color(0xFFFF9100)
        }

        if (trailPt != null) {
            scope.drawLine(
                color = color,
                start = Offset(pt.x, pt.y),
                end = Offset(trailPt.x, trailPt.y),
                strokeWidth = 3f
            )
        }
        scope.drawCircle(
            color = color,
            radius = 4f,
            center = Offset(pt.x, pt.y)
        )
    }

    private fun drawFloatingDamage(scope: DrawScope, dmg: FloatingDamageText, camera: Camera3D, w: Float, h: Float) {
        val pt = projectToScreen(dmg.position, camera, w, h) ?: return
        val paint = Paint().apply {
            color = if (dmg.isHeadshot) android.graphics.Color.RED else android.graphics.Color.YELLOW
            textSize = (if (dmg.isHeadshot) 34f else 26f) * (dmg.lifetimeSeconds.coerceIn(0.2f, 1f))
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        val text = if (dmg.isHeadshot) "💥 HEADSHOT -${dmg.damage.toInt()}" else "-${dmg.damage.toInt()}"
        scope.drawContext.canvas.nativeCanvas.drawText(
            text,
            pt.x,
            pt.y,
            paint
        )
    }
}
